//object
let Motel_Customer = {
    name: "Billy Worcestershire",
    birthDate: new Date("10/09/2000"),
    gender: "Male",
    roomPreferances: ["One bed", "Second floor"],
    paymentMethod: "Credit Card",
    mailingAddress: {streetAddress: "32 WestRoad Rd", province: "Ottawa", city: "Tiny Unknown City"},
    phoneNum: "(555)555-5555",
    checkIndate: new Date("10/09/2022"),
    checkOutdate: {date: new Date("10/11/2022")},
    
};


//math for customer age
let custAge = Math.trunc((new Date().getTime() - Motel_Customer.birthDate.getTime()) / (3.154e+10))

//math for time customer has stayed at the motel
let stayTime = (Motel_Customer.checkOutdate.date.getTime() - Motel_Customer.checkIndate.getTime()) / (8.64e+7)

let custParagraph = `${Motel_Customer.name} is a ${custAge} year old ${Motel_Customer.gender}, phone number is ${Motel_Customer.phoneNum}, 
${Motel_Customer.name} lives in ${Motel_Customer.mailingAddress.city} ${Motel_Customer.mailingAddress.province}, ${Motel_Customer.mailingAddress.streetAddress}.
${Motel_Customer.name} stayed at the motel for ${stayTime} days,
inbetween ${Motel_Customer.checkIndate} 
and ${Motel_Customer.checkOutdate.date}`

console.log(Motel_Customer);
console.log("");
console.log(custAge);
console.log("");
console.log(stayTime);
console.log("");
console.log(custParagraph);
